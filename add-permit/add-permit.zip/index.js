var mysql = require('mysql');
    
var connection = mysql.createConnection({
    host: 'parking-permits-v2.cqmzfyrm2poq.eu-west-2.rds.amazonaws.com',
    user: 'ppadmin',
    password: 'PvUWVVBuxLaulJkjSrHj',
    database: 'parking_permits_db_2'
});

exports.handler = async (event) => {
    let promise = new Promise((resolve, reject) => {
        let body = event.body;
        resolve({
            'isBase64Encoded': false,
            'statusCode': 200,
            'headers': {'contentType': 'application/json'},
            'multiValueHeaders': {},
            'body': JSON.stringify({
                'message': 'connection successful',
                'results': body,
                'registration': event
            })
        });
    });
    
    return promise;
};